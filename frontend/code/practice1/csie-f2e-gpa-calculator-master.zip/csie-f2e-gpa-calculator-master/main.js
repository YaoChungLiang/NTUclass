// 成績計算表單
const scoreForm = document.getElementById('scoreForm');
// 各科目分數輸入框
const zhInput = document.getElementById('chineseScoreInput');
const enInput = document.getElementById('englishScoreInput');
const mathInput = document.getElementById('mathScoreInput');
// 報告顯示區塊
const reportDiv = document.getElementById('result');

scoreForm.addEventListener('submit', function (e) {
    // 防止表單重整畫面
    e.preventDefault();
    // TODO: 取得各科目成績

    // TODO: 計算總分

    // TODO: 計算平均分數

    // TODO: 計算等級
    // 平均分數 >= 90 為A+
    // 平均分數 >= 80 為A
    // 平均分數 >= 70 為B
    // 平均分數 >= 60 為C
    // 平均分數 < 60 為F。

    // TODO: 顯示報告

});