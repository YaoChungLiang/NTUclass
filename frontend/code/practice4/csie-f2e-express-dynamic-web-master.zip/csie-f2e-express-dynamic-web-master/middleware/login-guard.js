// 設置登入者路由守衛
function loginGuard(router) {
    router.use(function (req, res, next) {
        // TODO: 登入者路由守衛

    });
}

module.exports = loginGuard;