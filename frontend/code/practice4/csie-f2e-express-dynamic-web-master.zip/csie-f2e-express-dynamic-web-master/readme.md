## Readme

### 快速開始
```
$ npm install
$ nodemon
```

### 如果過去未曾安裝過nodemon

```
$ npm i -g nodemon
```

MacOS需要輸入

```
$ sudo npm i -g nodemon --unsafe-perm
```

### 產生一個Express專案

```
$ express --view=ejs 專案名稱
```

進入專案資料夾
```
$ cd 專案名稱
```

安裝所需套件
```
$ npm install
```